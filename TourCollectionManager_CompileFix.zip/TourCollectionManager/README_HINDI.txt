TOUR COLLECTION MANAGER - ANDROID SOURCE PROJECT

IMPORTANT: Keep this complete folder structure intact. Do not upload the individual files flat into the GitHub repository.

Expected project structure:
TourCollectionManager/
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  app/
    build.gradle.kts
    src/main/AndroidManifest.xml
    src/main/java/com/tms/tourcollection/MainActivity.kt
    src/main/res/values/styles.xml
  .github/workflows/build-apk.yml

For phone-only GitHub build:
1. Upload this ZIP to the root of your GitHub repository with the exact name TourCollectionManager-source.zip.
2. In the repository, create or edit .github/workflows/build-apk.yml using the workflow provided separately in the chat.
3. Open Actions and run Build Android APK.
4. When successful, download the artifact named Tour-Collection-Manager-APK and extract app-debug.apk.

Do not upload student collection data or backups to GitHub. This archive contains app source code only.
